package StepDefinitions;

import io.cucumber.java.en.*;

public class LoginSteps {
	
	
	@Given("to open browser")
	public void to_open_browser() {
	    
		System.out.println("to open browser");
	}

	@When("user to open UHC HomePage")
	public void user_to_open_uhc_home_page() {
		
		System.out.println("to open browser");
	}

	@When("user to check all elements in HomePage")
	public void user_to_check_all_elements_in_home_page() {
		
		System.out.println("user to check all elements in HomePage");
	   
	}

	@When("user to input text in search box")
	public void user_to_input_text_in_search_box() {
		
		System.out.println("user to input text in search box");
	}

	@When("user to enter")
	public void user_to_enter() {
		
		System.out.println("user to enter");
	    
	}

	@Then("user to navigated to another page")
	public void user_to_navigated_to_another_page() {
		
		System.out.println("user to navigated to another page");
	    
	}


}
