package stepDefinitions;

import io.cucumber.java.en.*;

public class TestSteps {
	
	
	@Given("to open browser")
	public void to_open_browser() {
		
		System.out.println("test - to open broswer");
	    
	}

	@When("to provide url for home page")
	public void to_provide_url_for_home_page() {
		
		System.out.println("test - to provide url for home page");
	   
	}

	@When("to click on tab at menubar")
	public void to_click_on_tab_at_menubar() {
		
		System.out.println("test - to click on tab at menubar");
	   
	}

	@Then("navigating next page")
	public void navigating_next_page() {
	    
		
		System.out.println("test - navigating next page");
		
	}




}
